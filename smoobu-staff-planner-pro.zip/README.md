# Smoobu Staff Planner PRO

Start:

```
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
Admin: http://localhost:8000/admin/<ADMIN_TOKEN>
